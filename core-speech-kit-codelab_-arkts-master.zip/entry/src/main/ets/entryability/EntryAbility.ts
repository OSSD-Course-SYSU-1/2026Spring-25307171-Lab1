import { AbilityConstant, UIAbility, Want } from '@kit.AbilityKit';
import { window } from '@kit.ArkUI';
import { hilog } from '@kit.PerformanceAnalysisKit';

export default class EntryAbility extends UIAbility {
  onCreate(want: Want, launchParam: AbilityConstant.LaunchParam) {
    hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onCreate');
  }

  onDestroy() {
    hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onDestroy');
  }

  onWindowStageCreate(windowStage: window.WindowStage) {
    hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageCreate');

    windowStage.loadContent('pages/Index', (err, data) => {
      if (err.code) {
        hilog.error(0x0000, 'testTag', 'Failed to load the content. Cause: %{public}s', JSON.stringify(err) ?? '');
        return;
      }
      hilog.info(0x0000, 'testTag', 'Succeeded in loading the content. Data: %{public}s', JSON.stringify(data) ?? '');
    });
  }

  onWindowStageDestroy() {
    hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageDestroy');
  }

  onForeground() {
    hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onForeground');
  }

  onBackground() {
    hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onBackground');
  }

  /**
   * 接收流转数据
   */
  onNewWant(want: Want, launchParam: AbilityConstant.LaunchParam): void {
    super.onNewWant(want, launchParam);

    // 检查是否有流转参数
    if (want.parameters) {
      const text = want.parameters['text'] as string;
      const currentStatus = want.parameters['currentStatus'] as string;
      const isPlaying = want.parameters['isPlaying'] as boolean;
      const isDarkMode = want.parameters['isDarkMode'] as boolean;
      const settingsStr = want.parameters['settings'] as string;

      // 将数据存入全局对象，供页面读取
      globalThis.__continuationData__ = {
        text: text || '',
        currentStatus: currentStatus || '准备就绪',
        isPlaying: isPlaying || false,
        isDarkMode: isDarkMode || false,
        settings: settingsStr ? JSON.parse(settingsStr) : null
      };
    }
  }
}
